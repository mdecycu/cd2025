# pip install websocket-client websocket-server keyboard
import websocket
import json
import keyboard  # For capturing key presses

def send_command(direction):
    """Send control command to the robot."""
    server_ip = "your_ipv6_address"  # Replace with the Webots server's IPv6 address
    server_port = 8081  # Port
    ws_url = f"ws://[{server_ip}]:{server_port}"  # Use the IPv6 address in square brackets

    try:
        # Connect to the Webots server and send the command
        ws = websocket.create_connection(ws_url)
        message = json.dumps({"direction": direction})  # Create JSON message
        ws.send(message)
        print(f"Sent command: {direction}")
        ws.close()
    except Exception as e:
        print(f"Failed to send command {direction}: {e}")

def main():
    """Listen for arrow key presses and send commands."""
    print("Use arrow keys to control the robot (UP, DOWN, LEFT, RIGHT). Press 'ESC' to quit.")

    while True:
        try:
            if keyboard.is_pressed("up"):
                send_command("UP")
            elif keyboard.is_pressed("down"):
                send_command("DOWN")
            elif keyboard.is_pressed("left"):
                send_command("LEFT")
            elif keyboard.is_pressed("right"):
                send_command("RIGHT")
            elif keyboard.is_pressed("esc"):
                print("Exiting...")
                break
        except Exception as e:
            print(f"Error: {e}")
            break

if __name__ == "__main__":
    main()
function r = base_get_wheel(i)
  global wheel
  r = wheel(i);
end

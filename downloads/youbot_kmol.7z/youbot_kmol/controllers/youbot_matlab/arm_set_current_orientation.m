function arm_set_current_orientation(o)
  global current_orientation
  current_orientation=o;
end

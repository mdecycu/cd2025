function r = arm_get_element(i)
  global a
  r = a(i);
end

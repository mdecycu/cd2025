function arm_set_current_height(h)
  global current_height
  current_height=h;
end

function value = gripper_get_finger(f)
  global finger
  value = finger(f);
end

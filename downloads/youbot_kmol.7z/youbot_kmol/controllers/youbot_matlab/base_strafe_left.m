function base_strafe_left
  speeds = [4, -4, -4, 4];
  base_set_wheel_speeds_helper(speeds)
end

function arm_perform_reset
  arm_set_orientation('ARM_FRONT');
  arm_set_height('ARM_RESET');
end

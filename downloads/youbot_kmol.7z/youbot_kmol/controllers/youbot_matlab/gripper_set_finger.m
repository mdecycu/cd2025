function gripper_set_finger(f,v)
  global finger
  finger(f)=v;
  

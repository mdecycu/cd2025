function base_turn_right
  speeds = [4, -4, 4, -4];
  base_set_wheel_speeds_helper(speeds)
end

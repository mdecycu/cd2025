function arm_set_element(i,n)
  global a
  a(i) = n;
end

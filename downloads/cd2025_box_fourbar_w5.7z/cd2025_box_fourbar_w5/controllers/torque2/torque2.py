from controller import Robot, Keyboard

def run_robot():
    # Create the Robot instance
    robot = Robot()
    
    # Get simulation time step
    timestep = int(robot.getBasicTimeStep())
    
    # 初始化鍵盤，並設定取樣時間為 timestep
    keyboard = Keyboard()
    keyboard.enable(timestep)
    
    # Get motor device
    motor = robot.getDevice('motor1')
    
    # 設置馬達為力矩控制模式
    motor.setPosition(float('inf'))  # 解除位置控制限制
    motor.setVelocity(0.0)           # 初始速度設為0
    motor.setAvailableTorque(100.0)  # 設置最大可用扭矩
    motor.setTorque(0.0)             # 初始扭矩設為0
    
    # 追踪扭矩施加的時間
    torque_start_time = 0
    torque_applied = False
    torque_duration = 0.01  # 扭矩持續時間為0.1秒
    
    print("模擬開始. 按下 's' 施加100N.m扭矩0.01秒, 按下 'p' 停止扭矩.")
    
    # Main control loop
    while robot.step(timestep) != -1:
        # 取得當前模擬時間（秒）
        current_time = robot.getTime()
        
        # 取得鍵盤輸入
        key = keyboard.getKey()
        
        # 將 key 轉換為對應的字符
        key_char = chr(key).lower() if key != -1 else ''
        
        # 檢查是否需要停止施加扭矩
        if torque_applied and (current_time - torque_start_time) >= torque_duration:
            motor.setTorque(0.0)  # 停止施加扭矩
            torque_applied = False
            print("扭矩施加完成，已經過0.1秒")
        
        # 使用字符直接比較
        if key_char == 's' and not torque_applied:
            torque_applied = True
            torque_start_time = current_time
            motor.setPosition(float('inf'))  # 確保位置控制被解除
            motor.setTorque(100.0)  # 施加100N.m的扭矩
            print(f"已開始施加100N.m扭矩，將持續0.1秒")
            
        elif key_char == 'p' and torque_applied:
            torque_applied = False
            motor.setTorque(0.0)  # 立即停止施加扭矩
            print("已手動停止扭矩")

if __name__ == "__main__":
    run_robot()
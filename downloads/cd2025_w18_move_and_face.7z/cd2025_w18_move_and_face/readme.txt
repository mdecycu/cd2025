youbot_cart_w14_w_plate.wbt

size of plate on Youbot cart

length 50 cm
width 30 cm
height 2 cm

rotate angle: press a to rotate -30deg, press z to rotate 30deg

讓旋轉得更精準

1. 提前預判快到目標就提前減速/停止

    可以改成：當即將「接近」目標角度時，先把速度降成很小，最後慢慢逼近角度再停。

2. 允許一個容忍誤差 (tolerance)

    通常不用等到完全等於 30 度才停，可以設一個閾值，例如 29.5~30.5 度就停。

3. 計算超過目標時的補償（進階）

    可以記錄超過目標時的狀態，並反方向慢速微調回來。


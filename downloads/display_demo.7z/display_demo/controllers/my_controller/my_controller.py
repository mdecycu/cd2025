from controller import Supervisor

# Create the Supervisor instance
supervisor = Supervisor()

# Get the display node
display = supervisor.getDevice("display")

# Set the initial digit
digit = 0

# Set the font size
font_size = 24

# Main loop
while supervisor.step(int(supervisor.getBasicTimeStep())) != -1:
    # Clear the display
    display.setAlpha(1.0)
    display.setColor(0x000000)
    display.fillRectangle(0, 0, display.getWidth(), display.getHeight())
    
    # Draw the digit
    display.setAlpha(1.0)
    display.setColor(0xFFFFFF)
    display.setFont("Arial", font_size, True)
    display.drawText(str(digit), display.getWidth() // 2 - font_size, display.getHeight() // 2 - font_size)
    
    # Increment the digit
    digit += 1
    
    # Reset the digit after 100
    if digit > 100:
        digit = 0
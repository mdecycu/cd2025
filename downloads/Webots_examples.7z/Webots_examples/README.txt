# -*- mode:org; mode:visual-line; -*-

Webots demo worlds

1. pendulum-1-2-demo.wbt: underactuated double pendulum with two asymmetric distal links
   1. model: contained in world file
   2. controller: pendulum_1_2/pendulum_1_2.py

2. sensor-demo.wbt: two-link robot responding to obstacles
   1. model: protos/two-link.proto
   2. controller: two_link_sensor/two_link_sensor.py

3. controls-demo.wbt: several two-link robots responding to obstacles
   1. model: protos/two-link.proto
   2. controller: two_link/two_link.py
   3. controller: two_link_sensor/two_link_sensor.py

4. clock-demo.wbt: large clock with hands controlled to show the actual time
   1. model: protos/clock.proto
   2. controller: controllers/clock/clock.py

5. wobbly-demo.wbt: robot party with multiple mobile 'wobbly' robots in a large arena
   1. model: protos/wobbly.proto
   2. controller: controllers/wobbly/wobbly.py

6. network-party.wbt: wobbly robots and remote proxies controlled via MQTT messages over the network
   1. model: protos/delegate.proto
   2. model: protos/proxy.proto
   3. controller: controllers/disembod/disembod.py.

7. painting-demo.wbt: two-link arm spray-painting on the floor using inverse kinematic control
   1. model: protos/two-link.proto
   2. model: protos/painting.proto
   3. controller: two_link_sensor/two_link_ik.py
   4. controller: painting/painting.py

8. piano-keyboard.wbt: eight-key 'piano' keyboard controlled via MIDI
   1. model: protos/keyboard.proto
   2. controller: keyboard/keyboard.py

9. conveyor-demo.wbt: three-wheel 'active conveyor' with square manipulandum object on top
   1. model: contained in world file
   2. contained: conveyor/conveyor.py

10. impeller-demo.wbt: single-axis 'impeller' with rolling ball in a sloped arena
    1. model: contained in world file
    2. controller: impeller/impeller.py

11. suitcase-demo.wbt: four stepper motors mounted inside a suitcase on a pedestal
    1. model: robot contained in world file
    2. model: protos/suitcase.proto
    3. model: protos/pedestal.proto
    4. model: protos/ball_array.proto
    5. controller: suitcase/suitcase.py

12. pendulum-de-deux.wbt: two double-pendula side by side
    1. model: robot contained in world file
    2. controller: dbl_pend/dbl_pend.py

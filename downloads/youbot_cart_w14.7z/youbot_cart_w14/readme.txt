youbot_cart_w14_w_plate.wbt

size of plate on Youbot cart

length 50 cm
width 30 cm
height 2 cm
# Copyright 1996-2023 Cyberbotics Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Description:  Boomer tractor example

from controller import Robot, Motor, LED, Camera, Lidar, GPS, Keyboard
import math

# Constants
X, Y, Z = 0, 1, 2
FRONT_WHEEL_RADIUS = 0.38
REAR_WHEEL_RADIUS = 0.6

# Initialize robot
robot = Robot()
time_step = int(robot.getBasicTimeStep())

# Find wheels
left_front_wheel = robot.getDevice("left_front_wheel")
right_front_wheel = robot.getDevice("right_front_wheel")
left_rear_wheel = robot.getDevice("left_rear_wheel")
right_rear_wheel = robot.getDevice("right_rear_wheel")

left_front_wheel.setPosition(float('inf'))
right_front_wheel.setPosition(float('inf'))
left_rear_wheel.setPosition(float('inf'))
right_rear_wheel.setPosition(float('inf'))

# Get steering motors
left_steer = robot.getDevice("left_steer")
right_steer = robot.getDevice("right_steer")

# Camera device
camera = robot.getDevice("camera")
camera.enable(time_step)
camera_width = camera.getWidth()
camera_height = camera.getHeight()
camera_fov = camera.getFov()

# SICK sensor
sick = robot.getDevice("Sick LMS 291")
sick.enable(time_step)
sick_width = sick.getHorizontalResolution()
sick_range = sick.getMaxRange()
sick_fov = sick.getFov()

# Initialize GPS
gps = robot.getDevice("gps")
gps.enable(time_step)
gps_coords = [0, 0, 0]
gps_speed = 0.0

# Find lights
left_flasher = robot.getDevice("left_flasher")
right_flasher = robot.getDevice("right_flasher")
tail_lights = robot.getDevice("tail_lights")
work_head_lights = robot.getDevice("work_head_lights")
road_head_lights = robot.getDevice("road_head_lights")

# Misc variables
speed = 0.0
steering_angle = 0.0
manual_steering = 0.0

def blink_lights():
    on = int(robot.getTime()) % 2
    left_flasher.set(on)
    right_flasher.set(on)
    tail_lights.set(on)
    work_head_lights.set(on)
    road_head_lights.set(on)

def print_help():
    print("You can drive this vehicle!")
    print("Select the 3D window and then use the cursor keys to:")
    print("[LEFT]/[RIGHT] - steer")
    print("[UP]/[DOWN] - accelerate/slow down")

# Set target speed
def set_speed(kmh):
    global speed
    if kmh > 30.0:
        kmh = 30.0

    speed = kmh

    print(f"setting speed to {kmh} km/h")

    front_ang_vel = kmh * 1000.0 / 3600.0 / FRONT_WHEEL_RADIUS
    rear_ang_vel = kmh * 1000.0 / 3600.0 / REAR_WHEEL_RADIUS

    # Set motor rotation speed
    left_front_wheel.setVelocity(front_ang_vel)
    right_front_wheel.setVelocity(front_ang_vel)
    left_rear_wheel.setVelocity(rear_ang_vel)
    right_rear_wheel.setVelocity(rear_ang_vel)

# Positive: turn right, negative: turn left
def set_steering_angle(wheel_angle):
    global steering_angle
    steering_angle = wheel_angle
    left_steer.setPosition(steering_angle)
    right_steer.setPosition(steering_angle)

def change_manual_steer_angle(inc):
    global manual_steering
    new_manual_steering = manual_steering + inc
    print(f"steer {new_manual_steering}")
    if -0.94 <= new_manual_steering <= 0.94:
        manual_steering = new_manual_steering
        set_steering_angle(manual_steering)

    if manual_steering == 0:
        print("going straight")
    else:
        direction = "left" if steering_angle < 0 else "right"
        print(f"turning {steering_angle:.2f} rad ({direction})")

def check_keyboard():
    keyboard = robot.getKeyboard()
    key = keyboard.getKey()
    if key == Keyboard.UP:
        set_speed(speed + 1.0)
    elif key == Keyboard.DOWN:
        set_speed(speed - 1.0)
    elif key == ord(' '):
        set_speed(0.0)
    elif key == Keyboard.RIGHT:
        change_manual_steer_angle(+0.02)
    elif key == Keyboard.LEFT:
        change_manual_steer_angle(-0.02)

def compute_gps_speed():
    global gps_speed, gps_coords
    coords = gps.getValues()
    vel = [coords[X] - gps_coords[X], coords[Y] - gps_coords[Y], coords[Z] - gps_coords[Z]]
    dist = math.sqrt(vel[X]**2 + vel[Y]**2 + vel[Z]**2)

    # Store into global variables
    gps_speed = dist / time_step * 3600.0
    gps_coords = coords

    # print(f"gps speed: {gps_speed} km/h")

# Start engine
set_speed(10.0)  # km/h

print_help()

# Allow to switch to manual control
robot.getKeyboard().enable(time_step)

# Main loop
while robot.step(time_step) != -1:
    # Get user input
    check_keyboard()

    # Read sensors
    # camera_image = camera.getImage()
    # sick_data = sick.getRangeImage()

    # Update stuff
    compute_gps_speed()
    blink_lights()

robot.cleanup()
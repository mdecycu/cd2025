from controller import Robot, Keyboard

def run_robot():
    # Create the Robot instance
    robot = Robot()
    
    # Get simulation time step
    timestep = int(robot.getBasicTimeStep())
    
    # 初始化鍵盤，並設定取樣時間為 timestep
    keyboard = Keyboard()
    keyboard.enable(timestep)
    
    # Get motor device
    motor = robot.getDevice('motor1')
    
    # 設置馬達為力矩控制模式
    motor.setTorque(0.0)  # 初始扭矩為0
    
    # 設定一個變數來追踪扭矩是否已施加
    torque_applied = False
    
    print("模擬開始. 按下 's' 施加100N.m扭矩, 按下 'p' 停止扭矩.")
    
    # Main control loop
    while robot.step(timestep) != -1:
        # 取得鍵盤輸入
        key = keyboard.getKey()
        
        # 將 key 轉換為對應的字符
        key_char = chr(key).lower() if key != -1 else ''
        
        # 使用字符直接比較
        if key_char == 's':
            torque_applied = True
            motor.setTorque(1.0)  # 施加100N.m的扭矩
            print("已施加100N.m扭矩")
            
        elif key_char == 'p':
            torque_applied = False
            motor.setTorque(0.0)  # 停止施加扭矩
            print("已停止扭矩")

if __name__ == "__main__":
    run_robot()
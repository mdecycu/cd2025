import math
#print(math.pi)
deg=math.pi/180.
print(90.*deg)
from controller import Robot, Motor
import math

# 初始化機器人
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# 獲取馬達
vertical_motor = robot.getDevice('vertical_motor')

# 設置馬達參數
vertical_motor.setPosition(float('inf'))  # 連續旋轉模式
rotation_speed = math.radians(30)  # 每秒 30 度

# 主控制循環
while robot.step(timestep) != -1:
    # 設置馬達速度
    vertical_motor.setVelocity(rotation_speed)
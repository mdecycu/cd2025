from controller import Supervisor

supervisor = Supervisor()

# 設定模擬模式為實時啟動
supervisor.simulationSetMode(Supervisor.SIMULATION_MODE_REAL_TIME)
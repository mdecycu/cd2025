import asyncio
import websockets

async def send_commands():
    uri = "ws://[2001:288:6004:17:1111::1]:8765"  # Webots server IPv6 address
    async with websockets.connect(uri) as websocket:
        print("Connected to Webots server.")
        
        while True:
            command = input("Enter command (p to pause, s to start): ").strip().lower()
            if command in ["p", "s"]:
                await websocket.send(command)
            else:
                print("Invalid command!")
            
            # Listen for updates from the server
            try:
                message = await websocket.recv()
                print(f"Server: {message}")
            except websockets.ConnectionClosed:
                print("Connection closed.")
                break

if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(send_commands())
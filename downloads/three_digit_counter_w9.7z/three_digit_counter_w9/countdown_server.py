import asyncio
import websockets
from controller import Supervisor

class CountdownController:
    def __init__(self, supervisor, color_on, color_off):
        self.supervisor = supervisor
        self.timer = 999  # Start countdown from 999
        self.paused = False
        self.color_on = color_on
        self.color_off = color_off
        self.seven_segment = SevenSegmentController(supervisor, color_on, color_off)
        self.timestep = int(supervisor.getBasicTimeStep())

    async def countdown(self, websocket):
        while self.supervisor.step(self.timestep) != -1:
            if not self.paused and self.timer >= 0:
                self.seven_segment.display_number(self.timer)
                self.timer -= 1
                await websocket.send(f"Countdown: {self.timer}")
            await asyncio.sleep(1)  # Simulate 1-second interval

    def pause(self):
        self.paused = True

    def resume(self):
        self.paused = False


class SevenSegmentController:
    def __init__(self, supervisor, color_on, color_off):
        self.supervisor = supervisor
        self.color_on = color_on
        self.color_off = color_off
        self.digit_segments = [
            [f"a1", f"b1", f"c1", f"d1", f"e1", f"f1", f"g1"],  # Units
            [f"a2", f"b2", f"c2", f"d2", f"e2", f"f2", f"g2"],  # Tens
            [f"a3", f"b3", f"c3", f"d3", f"e3", f"f3", f"g3"]   # Hundreds
        ]
        self.segment_patterns = {
            0: [1, 1, 1, 1, 1, 1, 0],
            1: [0, 1, 1, 0, 0, 0, 0],
            2: [1, 1, 0, 1, 1, 0, 1],
            3: [1, 1, 1, 1, 0, 0, 1],
            4: [0, 1, 1, 0, 0, 1, 1],
            5: [1, 0, 1, 1, 0, 1, 1],
            6: [1, 0, 1, 1, 1, 1, 1],
            7: [1, 1, 1, 0, 0, 0, 0],
            8: [1, 1, 1, 1, 1, 1, 1],
            9: [1, 1, 1, 1, 0, 1, 1]
        }
        self.segment_nodes = []
        for digit in self.digit_segments:
            digit_nodes = []
            for segment in digit:
                node = self.supervisor.getFromDef(segment)
                if node is None:
                    print(f"Error: Node with DEF name '{segment}' not found!")
                    exit()
                digit_nodes.append(node.getField("diffuseColor"))
            self.segment_nodes.append(digit_nodes)

    def set_digit(self, digit_index, value):
        pattern = self.segment_patterns[value]
        for i, state in enumerate(pattern):
            color = self.color_on if state else self.color_off
            self.segment_nodes[digit_index][i].setSFVec3f(color)

    def display_number(self, number):
        if not (0 <= number <= 999):
            print("Error: Number out of range (must be 0-999)")
            return
        hundreds = number // 100
        tens = (number % 100) // 10
        units = number % 10
        self.set_digit(2, hundreds)
        self.set_digit(1, tens)
        self.set_digit(0, units)


async def handler(websocket, path):
    supervisor = Supervisor()
    color_on = [0.0, 1.0, 0.0]
    color_off = [0.0, 0.0, 0.0]
    countdown_controller = CountdownController(supervisor, color_on, color_off)

    # Start the countdown in a separate task
    asyncio.create_task(countdown_controller.countdown(websocket))

    async for message in websocket:
        if message == "p":
            countdown_controller.pause()
        elif message == "s":
            countdown_controller.resume()


start_server = websockets.serve(handler, "::", 8765)  # Bind to all IPv6 interfaces

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
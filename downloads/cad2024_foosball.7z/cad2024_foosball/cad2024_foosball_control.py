# pip install pyzmq cbor keyboard
# zmqRemoteApi_IPv6 為將 zmq 通訊協定修改為 IPv4 與 IPv6 相容
# for 4.5.1
# from zmqRemoteApi_IPv6 import RemoteAPIClient
# for 4.7.0
from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import keyboard

# 利用 zmqRemoteAPI 以 23000 對場景伺服器進行連線
client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')

# Get the handles of the ball objects
ball_handle = sim.getObject('/Sphere')

sim.startSimulation()
print('Simulation started')

# Define the thread function
def main():
    sim.setThreadAutomaticSwitch(True)
    
    joint = sim.getObject('./left_joint')
    hammer = sim.getObject('./left_player')
    slider = sim.getObject('./left_slider')

    velocity = 0
    hammer_back = 0
    torque = 0
    sliding = 0
    orientation = sim.getJointPosition(joint, sim.handle_world)
    position = sim.getObjectPosition(hammer, sim.handle_world)
    slider_position = sim.getJointPosition(slider, sim.handle_world)
    
    while True:
        if keyboard.is_pressed('w'):
            print("w is pressed")
            velocity = 100
            torque = 200
            hammer_back = 0
        if keyboard.is_pressed('s'):
            print("s is pressed")
            hammer_back = 1
            torque = -200
            velocity = -100
        if keyboard.is_pressed('a'):
            print("a is pressed")
            sliding = sliding + 0.05
        if keyboard.is_pressed('d'):
            print("d is pressed")
            sliding = sliding - 0.05
        if hammer_back == 1:
            sim.setJointPosition(joint, -1, orientation)
        sim.setJointTargetPosition(joint, velocity)
        sim.setJointTargetPosition(slider, sliding)

        if keyboard.is_pressed('q'):
            # Stop simulation
            sim.stopSimulation()
            break
    
# Create a child thread
main()

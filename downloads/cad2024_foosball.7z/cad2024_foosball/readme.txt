1. 控制程式包含 CoppeliaSim 4.5 與 4.7.0 等兩個版本

2. 4.7.0 需要使用 coppeliasim_zmqremoteapi_client 目錄中的程式庫模組

3. Python 需要利用 pip install pyzmq cbor keyboard 安裝 pyzmq cbor 以及 keyboard

4. cad2024_foosball_control_4.7.0.py 執行後, 會啟動模擬場景, 滑鼠點擊場景後, 按下 w 之後 player 會往後旋轉, 再按下 s 則會轉回原來的位置進行踢球動作.


from controller import Robot, PositionSensor, Gyro, Accelerometer
import matplotlib.pyplot as plt

TIME_STEP = 32
DURATION = 10  # 10 seconds

# Initialize the Webots robot
robot = Robot()

# Initialize the devices for the joints
joint1_motor = robot.getDevice("motor")
joint1_sensor = robot.getDevice("joint1_sensor")
joint1_sensor.enable(TIME_STEP)

joint2_sensor = robot.getDevice("joint2_sensor")
joint2_sensor.enable(TIME_STEP)

joint3_sensor = robot.getDevice("joint3_sensor")
joint3_sensor.enable(TIME_STEP)

joint4_sensor = robot.getDevice("joint4_sensor")
joint4_sensor.enable(TIME_STEP)

gyro = robot.getDevice("gyro")
gyro.enable(TIME_STEP)

accelerometer = robot.getDevice("accelerometer")
accelerometer.enable(TIME_STEP)

time_values = []
joint_speeds = {1: [], 2: [], 3: [], 4: []}
angular_velocities = {'x': [], 'y': [], 'z': []}
accelerations = {'x': [], 'y': [], 'z': []}

# Set the motor velocity to make the first joint rotate
joint1_motor.setPosition(float('inf'))
joint1_motor.setVelocity(1.0)  # Set a constant velocity

# Main loop
for i in range(int((10000 / TIME_STEP) * DURATION)):
    if robot.step(TIME_STEP) == -1:
        break

    # Read the speed of the joints
    speed1 = joint1_sensor.getValue()
    speed2 = joint2_sensor.getValue()
    speed3 = joint3_sensor.getValue()
    speed4 = joint4_sensor.getValue()

    # Read angular velocities
    gyro_values = gyro.getValues()
    angular_velocity_x = gyro_values[0]
    angular_velocity_y = gyro_values[1]
    angular_velocity_z = gyro_values[2]

    # Read accelerations
    accel_values = accelerometer.getValues()
    acceleration_x = accel_values[0]
    acceleration_y = accel_values[1]
    acceleration_z = accel_values[2]

    # Store data
    time_values.append(i * TIME_STEP / 1000.0)
    joint_speeds[1].append(speed1)
    joint_speeds[2].append(speed2)
    joint_speeds[3].append(speed3)
    joint_speeds[4].append(speed4)
    angular_velocities['x'].append(angular_velocity_x)
    angular_velocities['y'].append(angular_velocity_y)
    angular_velocities['z'].append(angular_velocity_z)
    accelerations['x'].append(acceleration_x)
    accelerations['y'].append(acceleration_y)
    accelerations['z'].append(acceleration_z)

# Plot the joint speed graph
plt.figure()
plt.subplot(2, 1, 1)
plt.plot(time_values, joint_speeds[1], label='Joint 1')
plt.plot(time_values, joint_speeds[2], label='Joint 2')
plt.plot(time_values, joint_speeds[3], label='Joint 3')
plt.plot(time_values, joint_speeds[4], label='Joint 4')
plt.xlabel('Time (s)')
plt.ylabel('Speed (rad/s)')
plt.title('Joint Speeds')
plt.legend()

# Plot the acceleration graph
plt.subplot(2, 1, 2)
plt.plot(time_values, angular_velocities['x'], label='Angular Velocity X')
plt.plot(time_values, angular_velocities['y'], label='Angular Velocity Y')
plt.plot(time_values, angular_velocities['z'], label='Angular Velocity Z')
plt.plot(time_values, accelerations['x'], label='Acceleration X')
plt.plot(time_values, accelerations['y'], label='Acceleration Y')
plt.plot(time_values, accelerations['z'], label='Acceleration Z')
plt.xlabel('Time (s)')
plt.ylabel('Acceleration (m/s^2)')
plt.title('Angular Velocities and Accelerations')
plt.legend()

plt.tight_layout()
plt.show()
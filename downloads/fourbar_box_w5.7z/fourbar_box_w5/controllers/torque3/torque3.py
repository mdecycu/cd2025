from controller import Robot, Keyboard

def run_robot():
    # Create the Robot instance
    robot = Robot()
    
    # Get simulation time step
    timestep = int(robot.getBasicTimeStep())
    
    # 初始化鍵盤，並設定取樣時間為 timestep
    keyboard = Keyboard()
    keyboard.enable(timestep)
    
    # Get motor device
    motor = robot.getDevice('motor1')
    
    # 設置馬達為力矩控制模式
    motor.setPosition(float('inf'))  # 解除位置控制限制
    motor.setVelocity(0.0)           # 初始速度設為0
    motor.setAvailableTorque(200.0)  # 設置最大可用扭矩
    motor.setTorque(0.0)             # 初始扭矩設為0
    
    # 取得位置感應器 (encoder)，用於獲取馬達速度
    try:
        position_sensor = motor.getPositionSensor()
        position_sensor.enable(timestep)
    except:
        # 如果馬達沒有內建位置感應器，則嘗試獲取單獨的感應器
        try:
            position_sensor = robot.getDevice(motor.getName() + "_sensor")
            position_sensor.enable(timestep)
        except:
            position_sensor = None
            print("警告：無法獲取位置感應器，將無法計算速度")
    
    # 摩擦力參數
    static_friction = 5.0     # 靜摩擦力（N.m）
    dynamic_friction = 3.0    # 動摩擦力係數（N.m.s/rad）
    
    # 追踪扭矩施加的時間和當前應用的扭矩
    torque_start_time = 0
    torque_applied = False
    torque_duration = 0.01     # 扭矩持續時間為0.1秒
    current_applied_torque = 0.0  # 手動追踪當前應用的扭矩
    
    # 追踪前一時刻的位置，用於計算速度
    prev_position = 0
    current_velocity = 0
    first_iteration = True
    
    print("模擬開始. 按下 's' 施加100N.m扭矩0.1秒（含摩擦力）, 按下 'p' 停止扭矩.")
    
    # Main control loop
    while robot.step(timestep) != -1:
        # 取得當前模擬時間（秒）
        current_time = robot.getTime()
        
        # 獲取馬達當前位置和計算速度
        if position_sensor:
            current_position = position_sensor.getValue()
            
            # 第一次迭代時初始化 prev_position
            if first_iteration:
                prev_position = current_position
                first_iteration = False
            
            # 計算速度（rad/s）
            current_velocity = (current_position - prev_position) / (timestep / 1000.0)
            prev_position = current_position
        
        # 計算摩擦力
        friction_torque = 0.0
        if position_sensor:  # 只有在有位置感應器時才計算摩擦力
            if abs(current_velocity) < 0.01:
                # 靜止或近似靜止狀態，應用靜摩擦力
                friction_torque = min(static_friction, abs(current_applied_torque)) * (-1 if current_applied_torque > 0 else 1)
            else:
                # 運動狀態，應用動摩擦力
                friction_torque = -dynamic_friction * current_velocity
        
        # 取得鍵盤輸入
        key = keyboard.getKey()
        
        # 將 key 轉換為對應的字符
        key_char = chr(key).lower() if key != -1 else ''
        
        # 檢查是否需要停止施加扭矩
        if torque_applied and (current_time - torque_start_time) >= torque_duration:
            motor.setTorque(0.0)
            current_applied_torque = 0.0
            torque_applied = False
            print("扭矩施加完成，已經過0.1秒")
        
        # 使用字符直接比較
        if key_char == 's' and not torque_applied:
            torque_applied = True
            torque_start_time = current_time
            motor.setPosition(float('inf'))  # 確保位置控制被解除
            
            # 施加目標扭矩
            target_torque = 150.0
            
            # 計算考慮摩擦力的有效扭矩
            effective_torque = target_torque
            if position_sensor:  # 只有在有位置感應器時才考慮摩擦力補償
                effective_torque = target_torque - friction_torque  # 減去摩擦力以抵消其影響
            
            motor.setTorque(effective_torque)
            current_applied_torque = effective_torque
            print(f"已開始施加30N.m扭矩，將持續0.1秒")
            if position_sensor:
                print(f"有效扭矩: {effective_torque:.2f}N.m (考慮摩擦力 {friction_torque:.2f}N.m)")
            
        elif key_char == 'p' and torque_applied:
            torque_applied = False
            motor.setTorque(0.0)
            current_applied_torque = 0.0
            print("已手動停止扭矩")
        
        # 如果沒有主動施加扭矩但有運動，且有位置感應器，則只應用摩擦力
        if not torque_applied and position_sensor and abs(current_velocity) > 0.01:
            motor.setTorque(friction_torque)
            current_applied_torque = friction_torque

if __name__ == "__main__":
    run_robot()
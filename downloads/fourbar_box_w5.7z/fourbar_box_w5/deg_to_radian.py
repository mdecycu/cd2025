import math
# link2 -z rotating angle
print((55.14*math.pi)/180)
# link3 -z rotating angle
print((90.5*math.pi)/180)